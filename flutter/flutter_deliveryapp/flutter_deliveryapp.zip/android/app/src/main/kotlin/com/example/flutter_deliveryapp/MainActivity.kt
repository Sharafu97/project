package com.example.flutter_deliveryapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
