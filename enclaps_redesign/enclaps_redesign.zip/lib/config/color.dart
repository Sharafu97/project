import 'package:flutter/material.dart';

const kcPrimary = Color(0xff35536D);
const kcWhite = Colors.white;
const kcDarkGreen = Color(0xff1A8EA1);
const kcGray = Color(0xff818799);
const kcBlack = Colors.black;
const kcBorderColor = Color(0xffCACFE2);
const kcBlue = Colors.blue;
const kcdarkgary = Color(0xff334356);
const kcPaymentTitle = Color(0xff4D5A6B);
const kcPaymentTile = Color(0xffE5E5E5);

const kcgd1 = Color(0xff009DE2);
const kcgd2 = Color(0xff009EE1);
const kcgd3 = Color(0xff00B8BD);
const kcgd4 = Color(0xff00CCA2);
const kcgd5 = Color(0xff00DA8E);
const kcgd6 = Color(0xff00E382);
const kcgd7 = Color(0xff00E67E);
const kcgd8 = Color(0xff009FDE);
const kcgd9 = Color(0xff5DC6C9);
