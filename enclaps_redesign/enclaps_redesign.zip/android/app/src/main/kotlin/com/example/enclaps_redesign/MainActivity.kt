package com.example.enclaps_redesign

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
